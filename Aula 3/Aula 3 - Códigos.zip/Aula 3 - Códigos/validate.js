const quadradoConstraint = {
    lado: {
        type: 'number',
    }
};

module.exports = { quadradoConstraint };
const Quadrado = require('./quadrado');

var pQuadrado = Quadrado.perimetro(true);
var aQuadrado = Quadrado.area(1);
console.log(pQuadrado);

const calculadoraConstraint = {
    num1: {
        type: 'number',
    },

    num2: {
        type: 'number',
    }
};

module.exports = { calculadoraConstraint };
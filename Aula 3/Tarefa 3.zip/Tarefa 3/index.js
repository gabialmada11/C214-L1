const Calculadora = require('./calculadora');

var aCalculadora = Calculadora.soma(1,2);
var bCalculadora = Calculadora.sub(8,2);
var cCalculadora = Calculadora.mult(5,2);
var dCalculadora = Calculadora.div(8,2);
var eCalculadora = Calculadora.raiz(4);
console.log(eCalculadora);
